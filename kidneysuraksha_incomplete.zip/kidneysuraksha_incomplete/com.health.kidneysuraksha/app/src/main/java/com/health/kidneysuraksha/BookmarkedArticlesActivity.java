package com.health.kidneysuraksha;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;
import java.util.List;

public class BookmarkedArticlesActivity extends AppCompatActivity {

    private RecyclerView recyclerViewBookmarkedArticles;
    private ArticlesAdapter articlesAdapter;
    private List<Article> articleList;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmarked_articles);

        recyclerViewBookmarkedArticles = findViewById(R.id.recyclerViewBookmarkedArticles);
        recyclerViewBookmarkedArticles.setLayoutManager(new LinearLayoutManager(this));
        articleList = new ArrayList<>();
        articlesAdapter = new ArticlesAdapter(articleList, this);
        recyclerViewBookmarkedArticles.setAdapter(articlesAdapter);

        db = FirebaseFirestore.getInstance();

        loadBookmarkedArticles();
    }

    private void loadBookmarkedArticles() {
        db.collection("user_bookmarks")
                .document("user_id") // Replace with actual user ID
                .collection("bookmarks")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        articleList.clear();
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            Article article = document.toObject(Article.class);
                            articleList.add(article);
                        }
                        articlesAdapter.notifyDataSetChanged();
                    }
                });
    }
}

package com.health.kidneysuraksha;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class ArticleCreationActivity extends AppCompatActivity {

    private EditText editTextTitle, editTextContent;
    private Button buttonSaveArticle;
    private FirebaseFirestore db;
    private Button buttonAddImage;
    private Button buttonAddVideo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article_creation);

        editTextTitle = findViewById(R.id.editTextTitle);
        editTextContent = findViewById(R.id.editTextContent);
        buttonSaveArticle = findViewById(R.id.buttonSaveArticle);
        buttonAddImage = findViewById(R.id.buttonAddImage);
        buttonAddVideo = findViewById(R.id.buttonAddVideo);
        db = FirebaseFirestore.getInstance();

        buttonAddImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle adding image
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, PICK_IMAGE_REQUEST);
            }
        });

        buttonAddVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle adding video
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, PICK_VIDEO_REQUEST);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            Uri selectedMediaUri = data.getData();
            if (requestCode == PICK_IMAGE_REQUEST) {
                // Handle image selection
                uploadMediaToFirebase(selectedMediaUri, "images");
            } else if (requestCode == PICK_VIDEO_REQUEST) {
                // Handle video selection
                uploadMediaToFirebase(selectedMediaUri, "videos");
            }
        }
    }

    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int PICK_VIDEO_REQUEST = 2;

    private void uploadMediaToFirebase(Uri mediaUri, String mediaType) {
        if (mediaUri != null) {
            StorageReference storageRef = FirebaseStorage.getInstance().getReference();
            StorageReference mediaRef = storageRef.child(mediaType + "/" + System.currentTimeMillis() + "." + getFileExtension(mediaUri));

            mediaRef.putFile(mediaUri)
                    .addOnSuccessListener(taskSnapshot -> mediaRef.getDownloadUrl().addOnSuccessListener(uri -> {
                        String mediaUrl = uri.toString();
                        // You can save the mediaUrl to Firestore or use it as needed
                    }))
                    .addOnFailureListener(e -> {
                        Toast.makeText(ArticleCreationActivity.this, "Failed to upload " + mediaType + ": " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        }
    }

    private String getFileExtension(Uri uri) {
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private void saveArticle(String title, String content) {
        Map<String, Object> article = new HashMap<>();
        article.put("title", title);
        article.put("content", content);

        db.collection("articles")
                .add(article)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(ArticleCreationActivity.this, "Article saved successfully.", Toast.LENGTH_SHORT).show();
                    // Redirect to main activity or clear fields
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(ArticleCreationActivity.this, "Error saving article: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}

package com.health.kidneysuraksha;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.google.android.material.navigation.NavigationView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.annotation.NonNull;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button buttonCreateArticle;
    private Button buttonViewArticles;
    private Button buttonRecommendations;
    private Button buttonTrendingArticles;
    private Button buttonSearch;
    private Button buttonProfileCustomization;
    private Button buttonBookmarkedArticles;

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!NoInternetActivity.isNetworkAvailable(this)) {
            startActivity(new Intent(this, NoInternetActivity.class));
            finish();
            return;
        }
        setContentView(R.layout.activity_main);

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_create_article:
                        startActivity(new Intent(MainActivity.this, ArticleCreationActivity.class));
                        break;
                    case R.id.nav_view_articles:
                        startActivity(new Intent(MainActivity.this, ViewArticlesActivity.class));
                        break;
                    case R.id.nav_recommendations:
                        startActivity(new Intent(MainActivity.this, RecommendationsActivity.class));
                        break;
                    case R.id.nav_trending_articles:
                        startActivity(new Intent(MainActivity.this, TrendingArticlesActivity.class));
                        break;
                    case R.id.nav_search:
                        startActivity(new Intent(MainActivity.this, SearchActivity.class));
                        break;
                    case R.id.nav_profile_customization:
                        startActivity(new Intent(MainActivity.this, ProfileCustomizationActivity.class));
                        break;
                    case R.id.nav_bookmarked_articles:
                        startActivity(new Intent(MainActivity.this, BookmarkedArticlesActivity.class));
                        break;
                }
                drawerLayout.closeDrawers();
                return true;
            }
        });

        buttonCreateArticle = findViewById(R.id.buttonCreateArticle);

        buttonCreateArticle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ArticleCreationActivity.class));
            }
        });
    buttonViewArticles = findViewById(R.id.buttonViewArticles);
    buttonViewArticles.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(MainActivity.this, ViewArticlesActivity.class));
        }
    });

    buttonRecommendations = findViewById(R.id.buttonRecommendations);
    buttonRecommendations.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(MainActivity.this, RecommendationsActivity.class));
        }
    });

    buttonTrendingArticles = findViewById(R.id.buttonTrendingArticles);
        buttonTrendingArticles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, TrendingArticlesActivity.class));
            }
        });

        // Fetch and display favorite articles
        String userId = "user_id"; // Replace with actual user ID
        db.collection("user_favorites")
                .document(userId)
                .collection("favorites")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<Article> favoriteArticles = new ArrayList<>();
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        Article article = document.toObject(Article.class);
                        favoriteArticles.add(article);
                    }
                    // Update UI with favorite articles
                    // Example: favoriteArticlesAdapter.updateList(favoriteArticles);
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(MainActivity.this, "Error fetching favorite articles: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });

    buttonSearch = findViewById(R.id.buttonSearch);
    buttonSearch.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(MainActivity.this, SearchActivity.class));
        }
    });

    buttonProfileCustomization = findViewById(R.id.buttonProfileCustomization);
    buttonProfileCustomization.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(MainActivity.this, ProfileCustomizationActivity.class));
        }
    });

    buttonBookmarkedArticles = findViewById(R.id.buttonBookmarkedArticles);
        buttonBookmarkedArticles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, BookmarkedArticlesActivity.class));
            }
        });

        Switch themeSwitch = findViewById(R.id.themeSwitch);
        themeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            }
        });
}

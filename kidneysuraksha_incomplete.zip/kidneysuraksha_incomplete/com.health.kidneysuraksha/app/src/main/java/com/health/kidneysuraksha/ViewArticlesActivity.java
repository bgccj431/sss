package com.health.kidneysuraksha;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class ViewArticlesActivity extends AppCompatActivity {

    private EditText editTextSearch;
    private RecyclerView recyclerViewArticles;
    private ArticlesAdapter articlesAdapter;
    private List<Article> articleList;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_articles);

        editTextSearch = findViewById(R.id.editTextSearch);
        recyclerViewArticles = findViewById(R.id.recyclerViewArticles);

        recyclerViewArticles.setLayoutManager(new LinearLayoutManager(this));
        articleList = new ArrayList<>();
        articlesAdapter = new ArticlesAdapter(articleList, this);
        recyclerViewArticles.setAdapter(articlesAdapter);

        db = FirebaseFirestore.getInstance();

        loadArticles();

        editTextSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterArticles(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void loadArticles() {
        db.collection("articles")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        articleList.clear();
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            Article article = document.toObject(Article.class);
                            articleList.add(article);
                        }
                        articlesAdapter.notifyDataSetChanged();
                    }
                });
    }

    private void filterArticles(String query) {
        List<Article> filteredList = new ArrayList<>();
        for (Article article : articleList) {
            if (article.getTitle().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(article);
            }
        }
        articlesAdapter.filterList(filteredList);
    }
}

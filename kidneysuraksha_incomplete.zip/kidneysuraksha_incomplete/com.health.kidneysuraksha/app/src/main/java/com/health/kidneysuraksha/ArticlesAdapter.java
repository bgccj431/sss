package com.health.kidneysuraksha;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class ArticlesAdapter extends RecyclerView.Adapter<ArticlesAdapter.ArticleViewHolder> {

    private List<Article> articleList;
    private Context context;
    private FirebaseFirestore db;

    public ArticlesAdapter(List<Article> articleList, Context context) {
        this.articleList = articleList;
        this.context = context;
        this.db = FirebaseFirestore.getInstance();
    }

    @NonNull
    @Override
    public ArticleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_article, parent, false);
        return new ArticleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ArticleViewHolder holder, int position) {
        Article article = articleList.get(position);
        holder.textViewTitle.setText(article.getTitle());
        holder.textViewContent.setText(article.getContent());
        holder.buttonLike.setText("Like (" + article.getLikes() + ")");
        holder.buttonLove.setText("Love (" + article.getLoves() + ")");

        holder.buttonLike.setOnClickListener(v -> {
            article.setLikes(article.getLikes() + 1);
            db.collection("articles").document(article.getTitle())
                    .update("likes", article.getLikes())
                    .addOnSuccessListener(aVoid -> notifyDataSetChanged());
        });

        holder.buttonLove.setOnClickListener(v -> {
            article.setLoves(article.getLoves() + 1);
            db.collection("articles").document(article.getTitle())
                    .update("loves", article.getLoves())
                    .addOnSuccessListener(aVoid -> notifyDataSetChanged());
        });

        holder.buttonShare.setOnClickListener(v -> {
            Intent shareIntent = new Intent();
            shareIntent.setAction(Intent.ACTION_SEND);
            shareIntent.putExtra(Intent.EXTRA_TEXT, article.getTitle() + "\n\n" + article.getContent());
            shareIntent.setType("text/plain");
            context.startActivity(Intent.createChooser(shareIntent, "Share via"));
        });

        holder.buttonSaveOffline.setOnClickListener(v -> {
            saveArticleOffline(article);
        });

        holder.buttonBookmark.setOnClickListener(v -> {
            bookmarkArticle(article);
        });

        holder.buttonDownloadImage.setOnClickListener(v -> {
            downloadImage(article.getImageUrl());
        });
    }

    private void bookmarkArticle(Article article) {
        // Save the article to Firestore under the user's bookmarks
        db.collection("user_bookmarks")
                .document("user_id") // Replace with actual user ID
                .collection("bookmarks")
                .document(article.getTitle())
                .set(article)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(context, "Article bookmarked.", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(context, "Error bookmarking article: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void saveArticleOffline(Article article) {
        // Save the article to local storage for offline viewing
        // You can use Room or SharedPreferences to save the article locally
        SharedPreferences sharedPreferences = context.getSharedPreferences("offline_articles", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(article.getTitle(), article.getContent());
        editor.apply();
        Toast.makeText(context, "Article saved for offline viewing.", Toast.LENGTH_SHORT).show();
    }

        holder.buttonAddComment.setOnClickListener(v -> {
            String commentText = holder.editTextComment.getText().toString().trim();
            if (!commentText.isEmpty()) {
                Comment comment = new Comment(commentText);
                db.collection("articles").document(article.getTitle())
                        .collection("comments").add(comment)
                        .addOnSuccessListener(documentReference -> {
                            holder.editTextComment.setText("");
                            loadComments(holder, article);
                        });
            }
        });
        loadComments(holder, article);
    }

    private void loadComments(ArticleViewHolder holder, Article article) {
        db.collection("articles").document(article.getTitle())
                .collection("comments").get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        List<Comment> commentList = new ArrayList<>();
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            Comment comment = document.toObject(Comment.class);
                            commentList.add(comment);
                        }
                        CommentsAdapter commentsAdapter = new CommentsAdapter(commentList);
                        holder.recyclerViewComments.setAdapter(commentsAdapter);
                    }
                });

    @Override
    public int getItemCount() {
        return articleList.size();
    }

    public void filterList(List<Article> filteredList) {
        articleList = filteredList;
        notifyDataSetChanged();
    }

    public static class ArticleViewHolder extends RecyclerView.ViewHolder {
        TextView textViewTitle, textViewContent;
        Button buttonLike, buttonLove;

        public ArticleViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewContent = itemView.findViewById(R.id.textViewContent);
            buttonLike = itemView.findViewById(R.id.buttonLike);
            buttonLove = itemView.findViewById(R.id.buttonLove);
        }
    }
}
